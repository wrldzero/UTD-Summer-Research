# Spotify Recommender App

To use this app:

1. Place your dataset in the file named `songs.csv` in this directory.
2. Run the app using:

   ```bash
   pip install -r requirements.txt
   streamlit run app.py
   ```

Make sure your `songs.csv` has the expected columns: `track_name`, `artist_name`, `genre`, `popularity`, and audio feature columns like `danceability`, `energy`, etc.
