
import pandas as pd
import numpy as np
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler

class Song:
    def __init__(self, index, title, artist, genre, popularity):
        self.index = index
        self.title = title
        self.artist = artist
        self.genre = genre
        self.popularity = popularity

    def __str__(self):
        return f"{self.index} {self.title} - {self.artist} ({self.genre}, popularity = {self.popularity})"

    def str_short(self):
        return f"{self.title} ({self.genre}, popularity = {self.popularity})"

class SpotifyRecommender:
    def __init__(self, df, k_neighbors=25):
        self.df = df.drop(columns=['Unnamed: 0'], errors='ignore').dropna()
        self.df = self.df[self.df['popularity'] > 0].reset_index(drop=True)

        self.features = [
            'danceability', 'energy', 'key', 'loudness', 'mode',
            'speechiness', 'acousticness', 'instrumentalness',
            'liveness', 'valence', 'tempo', 'time_signature', 'duration_ms'
        ]

        self.scaler = StandardScaler()
        self.scaled_features = self.scaler.fit_transform(self.df[self.features])

        self.knn = NearestNeighbors(n_neighbors=k_neighbors, metric='euclidean')
        self.knn.fit(self.scaled_features)

    def get_song(self, title, artist):
        matches = self.df[
            (self.df['track_name'].str.lower() == title.lower()) &
            (self.df['artist_name'].str.lower() == artist.lower())
        ]
        if len(matches) == 0:
            return None
        idx = matches.index[0]
        return Song(idx, matches.iloc[0]['track_name'], matches.iloc[0]['artist_name'],
                    matches.iloc[0]['genre'], matches.iloc[0]['popularity'])

    def recommend(self, title, artist, n_recommendations=10):
        song = self.get_song(title, artist)
        if song is None:
            raise ValueError("Song not found in dataset")

        liked_index = song.index
        liked_feature = self.scaled_features[liked_index].reshape(1, -1)

        distances, indices = self.knn.kneighbors(liked_feature)
        recommendations = []

        for idx in indices[0]:
            if idx != liked_index:
                recommendations.append(
                    Song(idx, self.df.iloc[idx]['track_name'], self.df.iloc[idx]['artist_name'],
                         self.df.iloc[idx]['genre'], self.df.iloc[idx]['popularity'])
                )
            if len(recommendations) >= n_recommendations:
                break

        return recommendations
