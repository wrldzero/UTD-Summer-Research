
import streamlit as st
import pandas as pd
from recommender import SpotifyRecommender

@st.cache_resource
def load_model():
    df = pd.read_csv("songs.csv")
    return SpotifyRecommender(df)

st.set_page_config(page_title="Spotify Recommender", layout="centered")
st.title("🎧 Spotify Recommender")
st.markdown("Enter a song title and artist to get similar tracks.")

model = load_model()

title = st.text_input("Song Title", "Blinding Lights")
artist = st.text_input("Artist Name", "The Weeknd")

if st.button("Get Recommendations"):
    try:
        recs = model.recommend(title, artist)
        st.subheader("🔁 Recommended Songs")
        for song in recs:
            st.markdown(f"- **{song.title}** by *{song.artist}* ({song.genre})")
    except ValueError as e:
        st.error(str(e))
